=====================zm_QueenS_d2===========================

map by madafakus

have FUN :)
