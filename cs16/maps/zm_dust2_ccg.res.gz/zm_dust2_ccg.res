//////////////////////////////////////////////////////////
// Resources file, created with 17buddies php script!!! //
// © Chapo 2005-2013 - Infos @ http://www.17buddies.net //
//          More than 85000 maps to download!           //
//////////////////////////////////////////////////////////
// Map Name  : zm_dust2_ccg
// Download @: http://www.17buddies.net/17b2/View/Map/70279/zm_dust2_ccg.html
// (.res file generated with script version 3.0)
//////////////////////////////////////////////////////////
// Wad files legend:
//     *  : Hardcoded in bsp file, this wad was found (in
//          archive or on 17Buddies's website) but doesn't
//          contains any used texture.
//          However, this file may be necessary.
//     ** : Hardcoded in bsp file, this wad could not be
//          found (neither in archive nor on 17Buddies's
//          website) and thus could not be analysed.
//          However, this file may be necessary.
//////////////////////////////////////////////////////////
cs_havana.wad
// cs_office.wad (*)
cs_dust.wad
// cs_cbble.wad (*)
// de_airstrip.wad (*)
// cs_assault.wad (*)
// de_vertigo.wad (*)
// de_storm.wad (*)
de_aztec.wad
// de_piranesi.wad (*)
cs_747.wad
chateau.wad
torntextures.wad
// cstraining.wad (*)
// itsitaly.wad (*)
gfx/env/sky_wasteland02up.tga
gfx/env/sky_wasteland02dn.tga
gfx/env/sky_wasteland02lf.tga
gfx/env/sky_wasteland02rt.tga
gfx/env/sky_wasteland02ft.tga
gfx/env/sky_wasteland02bk.tga
// models/mil_crategibs.mdl
